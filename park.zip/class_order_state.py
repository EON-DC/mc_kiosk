class OrderState:
    def __init__(self):
        pass
    