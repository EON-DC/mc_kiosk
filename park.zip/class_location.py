class Location:
    def __init__(self):
        pass
    